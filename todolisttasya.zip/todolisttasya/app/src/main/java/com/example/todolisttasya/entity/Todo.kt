package com.example.todolisttasya.entity

import android.R

data class Todo(
    val id: String,
    val title: String,
    val description: String,
)
