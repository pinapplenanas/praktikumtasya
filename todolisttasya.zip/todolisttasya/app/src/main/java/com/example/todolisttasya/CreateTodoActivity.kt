package com.example.todolisttasya

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.example.todolisttasya.databinding.ActivityCreateTodoBinding
import com.example.todolisttasya.entity.Todo
import com.example.todolisttasya.usecases.TodoUseCase
import kotlinx.coroutines.launch

class CreateTodoActivity : AppCompatActivity() {
    private lateinit var activityBinding: ActivityCreateTodoBinding
    private lateinit var todoUseCase: TodoUseCase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        activityBinding = ActivityCreateTodoBinding.inflate(layoutInflater)
        setContentView(activityBinding.root)

        // FIXED 👇 (buat object bukan companion)
        todoUseCase = TodoUseCase()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        registerEvents()
    }

    private fun registerEvents() {
        activityBinding.tombolTambah.setOnClickListener {
            saveTodoToFirestore()
        }
    }

    private fun saveTodoToFirestore() {
        val title = activityBinding.title.text.toString()
        val description = activityBinding.description.text.toString()

        if (title.isEmpty() || description.isEmpty()) {
            Toast.makeText(this, "Judul dan deskripsi tidak boleh kosong!", Toast.LENGTH_SHORT).show()
            return
        }

        // FIXED 👇 (field benar: description)
        val todo = Todo(
            id = "",
            title = title,
            description = description
        )

        lifecycleScope.launch {
            try {
                todoUseCase.createTodo(todo)
                Toast.makeText(this@CreateTodoActivity, "Sukses menambahkan data", Toast.LENGTH_SHORT).show()
                toTodoListPage()
            } catch (exc: Exception) {
                Toast.makeText(this@CreateTodoActivity, exc.message, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun toTodoListPage() {
        startActivity(Intent(this, TodoActivity::class.java))
        finish()
    }
}
