package com.example.todolisttasya

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.todolisttasya.adapter.TodoAdapter
import com.example.todolisttasya.databinding.ActivityTodoactivityBinding
import com.example.todolisttasya.usecases.TodoUseCase
import kotlinx.coroutines.launch

class TodoActivity : AppCompatActivity() {
    private lateinit var activityBinding: ActivityTodoactivityBinding
    private lateinit var todoAdapter: TodoAdapter
    private lateinit var todoUseCase: TodoUseCase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        activityBinding = ActivityTodoactivityBinding.inflate(layoutInflater)
        setContentView(activityBinding.root)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        setupRecyclerView()
        initializeData()
        registerEvents()
    }

    fun registerEvents() {
        activityBinding.tombooTambah.setOnClickListener {
            toCreateTodoPage()
        }
    }

    fun setupRecyclerView() {
        todoAdapter = TodoAdapter (mutableListOf())

        activityBinding.container.adapter = todoAdapter
        activityBinding.container.layoutManager = LinearLayoutManager(this)
    }

    fun initializeData() {
        activityBinding.container.visibility = View.GONE
        activityBinding.loading.visibility = View.VISIBLE

        lifecycleScope.launch {
            val data = todoUseCase.getTodo()
            activityBinding.container.visibility = View.VISIBLE
            activityBinding.loading.visibility = View.GONE

            todoAdapter.updateDataSet(data)
        }
    }

    fun toCreateTodoPage() {
        val intent = Intent(this, CreateTodoActivity::class.java)
        startActivity(intent)
        finish()
    }
}